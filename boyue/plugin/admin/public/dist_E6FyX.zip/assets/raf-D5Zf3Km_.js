import{bl as e}from"./index-CyUgAjQc.js";const i=i=>e?window.requestAnimationFrame(i):setTimeout(i,16),o=i=>e?window.cancelAnimationFrame(i):clearTimeout(i);export{o as c,i as r};
